Objects through time
960 x 540; 24 fps; 3 frames; silent; mode alpha.
Frame 000000 starts at project time 3.
Import as an image sequence in your video editor.
